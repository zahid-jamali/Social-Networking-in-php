<html>
<head>
<title>iSecure</title>
<style>
	*{
		padding: auto;
		margin: auto;
	}
	.nav{
		width: 100%;
		height: 100px;
		line-height: 6;
		//text-algin: center;
		background-color: black;
		padding-left: 45%;
	}
	body{
		background-color: skyblue;
	}
</style>
</head>
<body>
<h1 align="center">iSecure</h1>
<hr color="red">
<div class="nav">

	<a href="newuser.php"><button>New-user</button></a>
	<a href="login.php"><button>Log-in</button></a>

</div>
</body>
</html>